<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Siswa - E-Learning</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Sidebar responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar-open {
                transform: translateX(0);
            }

            .overlay {
                display: none;
            }

            .overlay-active {
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 40;
            }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen">
    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <main class="md:ml-64 min-h-screen p-4 md:p-6 transition-all duration-300">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold text-gray-900">Edit Data Siswa</h1>
                    <p class="text-gray-600 mt-1">Perbarui informasi siswa: <?php echo e($siswa->nama); ?></p>
                </div>
                <a href="<?php echo e(route('admin.siswa.index')); ?>"
                    class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-medium inline-flex items-center transition">
                    <i class="fas fa-arrow-left mr-2"></i>Kembali
                </a>
            </div>

            <?php if($errors->any()): ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-circle text-red-500"></i>
                    </div>
                    <div class="ml-3">
                        <h3 class="text-sm font-medium text-red-800">Ada kesalahan dalam pengisian form</h3>
                        <div class="mt-2 text-sm text-red-700">
                            <ul class="list-disc list-inside space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Form -->
            <form action="<?php echo e(route('admin.siswa.update', $siswa->nisn)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <!-- Kolom 1 -->
                    <div class="space-y-4">
                        <!-- NISN (readonly) -->
                        <div>
                            <label for="nisn" class="block text-sm font-medium text-gray-700 mb-1">
                                NISN
                            </label>
                            <input type="text" id="nisn" value="<?php echo e($siswa->nisn); ?>" readonly
                                class="w-full px-4 py-3 border border-gray-300 bg-gray-50 rounded-lg">
                            <p class="mt-2 text-xs text-gray-500">NISN tidak dapat diubah</p>
                        </div>

                        <!-- NIS -->
                        <div>
                            <label for="nis" class="block text-sm font-medium text-gray-700 mb-1">
                                NIS <span class="text-red-500">*</span>
                            </label>
                            <input type="text" id="nis" name="nis" value="<?php echo e(old('nis', $siswa->nis)); ?>"
                                required maxlength="4"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                                placeholder="Masukkan 4 digit NIS" pattern="[0-9]{4}"
                                title="Masukkan 4 digit angka NIS">
                            <p class="mt-2 text-xs text-gray-500">4 digit angka NIS</p>
                        </div>

                        <!-- Nama -->
                        <div>
                            <label for="nama" class="block text-sm font-medium text-gray-700 mb-1">
                                Nama Lengkap <span class="text-red-500">*</span>
                            </label>
                            <input type="text" id="nama" name="nama" value="<?php echo e(old('nama', $siswa->nama)); ?>"
                                required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                                placeholder="Masukkan nama lengkap">
                        </div>

                        <!-- Email -->
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                                Email
                            </label>
                            <input type="email" id="email" name="email"
                                value="<?php echo e(old('email', $siswa->email)); ?>"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                                placeholder="nama@email.com">
                        </div>

                        <!-- Tempat Lahir -->
                        <div>
                            <label for="tempat_lahir" class="block text-sm font-medium text-gray-700 mb-1">
                                Tempat Lahir
                            </label>
                            <input type="text" id="tempat_lahir" name="tempat_lahir"
                                value="<?php echo e(old('tempat_lahir', $siswa->tempat_lahir)); ?>"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                                placeholder="Kota Kelahiran">
                        </div>

                        <!-- Tanggal Lahir -->
                        <div>
                            <label for="tanggal_lahir" class="block text-sm font-medium text-gray-700 mb-1">
                                Tanggal Lahir
                            </label>
                            <input type="date" id="tanggal_lahir" name="tanggal_lahir"
                                value="<?php echo e(old('tanggal_lahir', $siswa->tanggal_lahir)); ?>"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                        </div>

                        <!-- Agama -->
                        <div>
                            <label for="agama" class="block text-sm font-medium text-gray-700 mb-1">
                                Agama
                            </label>
                            <select id="agama" name="agama"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                                <option value="">Pilih Agama</option>
                                <option value="Islam" <?php echo e(old('agama', $siswa->agama) == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                                <option value="Kristen" <?php echo e(old('agama', $siswa->agama) == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                                <option value="Katolik" <?php echo e(old('agama', $siswa->agama) == 'Katolik' ? 'selected' : ''); ?>>Katolik</option>
                                <option value="Hindu" <?php echo e(old('agama', $siswa->agama) == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                                <option value="Buddha" <?php echo e(old('agama', $siswa->agama) == 'Buddha' ? 'selected' : ''); ?>>Buddha</option>
                                <option value="Konghucu" <?php echo e(old('agama', $siswa->agama) == 'Konghucu' ? 'selected' : ''); ?>>Konghucu</option>
                            </select>
                        </div>
                    </div>

                    <!-- Kolom 2 -->
                    <div class="space-y-4">
                        <!-- Kelas -->
                        <div>
                            <label for="kelas_id" class="block text-sm font-medium text-gray-700 mb-1">
                                Kelas <span class="text-red-500">*</span>
                            </label>
                            <select id="kelas_id" name="kelas_id" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                                <option value="">Pilih Kelas</option>
                                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"
                                    <?php echo e(old('kelas_id', $siswa->kelas_id) == $item->id ? 'selected' : ''); ?>>
                                    <?php echo e($item->kelas); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Tingkat -->
                        <div>
                            <label for="tingkat" class="block text-sm font-medium text-gray-700 mb-1">
                                Tingkat
                            </label>
                            <select id="tingkat" name="tingkat"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                                <option value="">Pilih Tingkat</option>
                                <option value="7" <?php echo e(old('tingkat', $siswa->tingkat) == '7' ? 'selected' : ''); ?>>Kelas 7</option>
                                <option value="8" <?php echo e(old('tingkat', $siswa->tingkat) == '8' ? 'selected' : ''); ?>>Kelas 8</option>
                                <option value="9" <?php echo e(old('tingkat', $siswa->tingkat) == '9' ? 'selected' : ''); ?>>Kelas 9</option>
                            </select>
                        </div>

                        <!-- Jenis Kelamin -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Jenis Kelamin <span class="text-red-500">*</span>
                            </label>
                            <div class="flex space-x-6">
                                <label class="inline-flex items-center">
                                    <input type="radio" name="jnsklmn" value="L"
                                        <?php echo e(old('jnsklmn', $siswa->jnsklmn) == 'L' ? 'checked' : ''); ?>

                                        class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" required>
                                    <span class="ml-2 text-sm text-gray-700">Laki-laki</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="radio" name="jnsklmn" value="P"
                                        <?php echo e(old('jnsklmn', $siswa->jnsklmn) == 'P' ? 'checked' : ''); ?>

                                        class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500" required>
                                    <span class="ml-2 text-sm text-gray-700">Perempuan</span>
                                </label>
                            </div>
                        </div>

                        <!-- No Telepon -->
                        <div>
                            <label for="no_telp" class="block text-sm font-medium text-gray-700 mb-1">
                                No. Telepon
                            </label>
                            <input type="text" id="no_telp" name="no_telp"
                                value="<?php echo e(old('no_telp', $siswa->no_telp)); ?>"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                                placeholder="08xxxxxxxxxx" pattern="[0-9]{10,13}" title="Masukkan 10-13 digit angka">
                        </div>
                    </div>
                </div>

                <!-- Alamat -->
                <div class="mb-6">
                    <label for="alamat" class="block text-sm font-medium text-gray-700 mb-1">
                        Alamat
                    </label>
                    <textarea id="alamat" name="alamat" rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="Masukkan alamat lengkap"><?php echo e(old('alamat', $siswa->alamat)); ?></textarea>
                </div>

                <!-- Info Login -->
                <div class="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <div class="flex items-start">
                        <i class="fas fa-info-circle text-blue-500 mt-1 mr-3"></i>
                        <div>
                            <h4 class="text-sm font-semibold text-blue-800 mb-1">Informasi Login:</h4>
                            <div class="text-sm text-blue-700 space-y-1">
                                <p><strong class="font-medium">Username:</strong> <?php echo e($siswa->nisn); ?></p>
                                <p><strong class="font-medium">Password:</strong> <?php echo e($siswa->nis); ?></p>
                            </div>
                
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('admin.siswa.index')); ?>"
                        class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg text-sm font-medium text-center transition">
                        Batal
                    </a>
                    <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg text-sm font-medium inline-flex items-center justify-center transition">
                        <i class="fas fa-save mr-2"></i>Update Data
                    </button>
                </div>
            </form>
        </div>
    </main>
</body>

</html><?php /**PATH C:\Users\Asus\Desktop\elearning\resources\views/admin/siswa/edit.blade.php ENDPATH**/ ?>