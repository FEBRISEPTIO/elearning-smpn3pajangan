<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengumpulan Tugas - <?php echo e($tugas->judul_tugas); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Sidebar responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar-open {
                transform: translateX(0);
            }

            .overlay {
                display: none;
            }

            .overlay-active {
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 40;
            }
        }

        #nilaiModal {
            display: none;
        }

        #nilaiModal:not(.hidden) {
            display: flex;
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen">
    <?php echo $__env->make('guru.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="md:ml-64 min-h-screen p-4 md:p-6 transition-all duration-300">
        <!-- Header -->
        <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
            <div>
                <h1 class="text-2xl md:text-3xl font-bold text-gray-900">Pengumpulan Tugas</h1>
                <p class="text-gray-600 mt-1"><?php echo e($tugas->judul_tugas); ?></p>
                <div class="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <span><i class="fas fa-users mr-1"></i>Kelas: <?php echo e($tugas->kelas->kelas ?? '-'); ?></span>
                    <span><i class="fas fa-book mr-1"></i>Mapel: <?php echo e($tugas->mataPelajaran->nama_mapel ?? '-'); ?></span>
                </div>
            </div>
            <div class="flex gap-3">
                <a href="<?php echo e(route('guru.tugas.show', $tugas->id)); ?>"
                    class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-medium inline-flex items-center transition">
                    <i class="fas fa-arrow-left mr-2"></i>Kembali ke Tugas
                </a>
                <div class="text-right">
                    <p class="text-sm text-gray-500">Deadline</p>
                    <p
                        class="font-medium <?php echo e(now()->greaterThan($tugas->deadline) ? 'text-red-600' : 'text-green-600'); ?>">
                        <?php echo e($tugas->deadline->format('d M Y, H:i')); ?>

                    </p>
                    <?php if(now()->greaterThan($tugas->deadline)): ?>
                        <span class="text-xs text-red-500">(Sudah lewat)</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Statistik -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div class="flex items-center">
                    <div class="bg-blue-100 rounded-full p-3 mr-4">
                        <i class="fas fa-users text-blue-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Total Siswa</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo e($totalSiswa); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-green-50 border border-green-200 rounded-xl p-4">
                <div class="flex items-center">
                    <div class="bg-green-100 rounded-full p-3 mr-4">
                        <i class="fas fa-check-circle text-green-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Sudah Kumpul</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo e($sudahKumpul); ?></p>
                        <p class="text-xs text-gray-500">
                            <?php if($totalSiswa > 0): ?>
                                <?php echo e(number_format(($sudahKumpul / $totalSiswa) * 100, 0)); ?>%
                            <?php else: ?>
                                0%
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <div class="flex items-center">
                    <div class="bg-yellow-100 rounded-full p-3 mr-4">
                        <i class="fas fa-clock text-yellow-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Belum Kumpul</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo e($belumKumpul); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-red-50 border border-red-200 rounded-xl p-4">
                <div class="flex items-center">
                    <div class="bg-red-100 rounded-full p-3 mr-4">
                        <i class="fas fa-exclamation-triangle text-red-600"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Terlambat</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo e($terlambat); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daftar Pengumpulan -->
        <div class="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
            <div class="px-6 py-4 border-b bg-gray-50">
                <h2 class="text-lg font-semibold text-gray-900">Daftar Pengumpulan Siswa</h2>
                <p class="text-sm text-gray-600 mt-1">Daftar tugas yang sudah dikumpulkan siswa</p>
            </div>

            <?php if($pengumpulan->count() > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Siswa
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Waktu Pengumpulan
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    File
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Keterangan
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $pengumpulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div
                                                class="shrink-0 h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                                                <i class="fas fa-user-graduate text-gray-600"></i>
                                            </div>
                                            <div>
                                                <div class="font-medium text-gray-900">
                                                    <?php echo e($item->siswa->nama ?? 'Siswa'); ?></div>
                                                <div class="text-sm text-gray-500">
                                                    NISN: <?php echo e($item->siswa->nisn ?? '-'); ?> |
                                                    NIS: <?php echo e($item->siswa->nis ?? '-'); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php echo e($item->submitted_at->format('d M Y, H:i')); ?>

                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo e($item->submitted_at->diffForHumans()); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($item->status == 'late'): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                <i class="fas fa-clock mr-1"></i> Terlambat
                                            </span>
                                        <?php elseif($item->status == 'graded'): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <i class="fas fa-check-circle mr-1"></i> Sudah Dinilai
                                            </span>
                                            <?php if($item->nilai): ?>
                                                <div class="text-sm font-medium text-gray-900 mt-1">
                                                    Nilai: <?php echo e($item->nilai); ?>

                                                </div>
                                            <?php endif; ?>
                                        <?php elseif($item->status == 'submitted'): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                <i class="fas fa-paper-plane mr-1"></i> Terkirim
                                            </span>
                                        <?php else: ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                                <i class="fas fa-question-circle mr-1"></i> <?php echo e($item->status); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($item->file): ?>
                                            <?php
                                                $extension = pathinfo($item->file, PATHINFO_EXTENSION);
                                                $iconClass =
                                                    [
                                                        'pdf' => 'fas fa-file-pdf text-red-500',
                                                        'doc' => 'fas fa-file-word text-blue-500',
                                                        'docx' => 'fas fa-file-word text-blue-500',
                                                        'ppt' => 'fas fa-file-powerpoint text-orange-500',
                                                        'pptx' => 'fas fa-file-powerpoint text-orange-500',
                                                        'jpg' => 'fas fa-file-image text-green-500',
                                                        'jpeg' => 'fas fa-file-image text-green-500',
                                                        'png' => 'fas fa-file-image text-green-500',
                                                        'zip' => 'fas fa-file-archive text-purple-500',
                                                        'rar' => 'fas fa-file-archive text-purple-500',
                                                    ][strtolower($extension)] ?? 'fas fa-file text-gray-500';
                                            ?>
                                            <div class="flex items-center">
                                                <div class="<?php echo e($iconClass); ?> text-lg mr-2"></div>
                                                <div>
                                                    <div class="text-sm text-gray-900">
                                                        <?php echo e(basename($item->file)); ?>

                                                    </div>
                                                    <div class="text-xs text-gray-500">
                                                        <?php echo e(strtoupper($extension)); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900 max-w-xs">
                                            <?php echo e($item->keterangan ?? 'Tidak ada keterangan'); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex items-center space-x-2">
                                            <?php if($item->file): ?>
                                                <a href="<?php echo e(Storage::url($item->file)); ?>" download
                                                    class="text-blue-600 hover:text-blue-900 p-2 hover:bg-blue-50 rounded"
                                                    title="Download File">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            <?php endif; ?>

                                            <button
                                                onclick="openNilaiModal(<?php echo e($item->id); ?>, <?php echo e($item->nilai ?? 0); ?>, '<?php echo e($item->feedback ?? ''); ?>')"
                                                class="text-green-600 hover:text-green-900 p-2 hover:bg-green-50 rounded"
                                                title="Beri Nilai">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <form action="<?php echo e(route('guru.tugas.hapus-pengumpulan', $item->id)); ?>"
                                                method="POST" class="inline"
                                                onsubmit="return confirm('Hapus pengumpulan ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="text-red-600 hover:text-red-900 p-2 hover:bg-red-50 rounded"
                                                    title="Hapus Pengumpulan">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if($pengumpulan->hasPages()): ?>
                    <div class="px-6 py-4 border-t">
                        <?php echo e($pengumpulan->links()); ?>

                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-12">
                    <div class="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-inbox text-gray-400 text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Belum ada pengumpulan</h3>
                    <p class="text-gray-500">Belum ada siswa yang mengumpulkan tugas ini.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Daftar Siswa Belum Kumpul -->
        <?php if($belumKumpul > 0): ?>
            <div class="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
                <div class="px-6 py-4 border-b bg-yellow-50">
                    <h2 class="text-lg font-semibold text-gray-900">Siswa Belum Mengumpulkan (<?php echo e($belumKumpul); ?>)
                    </h2>
                    <p class="text-sm text-gray-600 mt-1">Siswa yang belum mengumpulkan tugas</p>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <?php $__currentLoopData = $siswaBelumKumpul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border border-gray-200 rounded-lg p-4">
                                <div class="flex items-center">
                                    <div
                                        class="shrink-0 h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                                        <i class="fas fa-user text-gray-600"></i>
                                    </div>
                                    <div>
                                        <div class="font-medium text-gray-900"><?php echo e($siswa->nama); ?></div>
                                        <div class="text-sm text-gray-500">
                                            NISN: <?php echo e($siswa->nisn); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Tips -->
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-start">
                <i class="fas fa-lightbulb text-amber-500 mt-1 mr-3"></i>
                <div>
                    <h4 class="text-sm font-semibold text-blue-800 mb-2">Tips Penilaian Tugas:</h4>
                    <ul class="text-sm text-blue-700 space-y-1">
                        <li>• Berikan nilai dengan kriteria yang jelas</li>
                        <li>• Sertakan feedback yang membangun</li>
                        <li>• Perhatikan ketepatan waktu pengumpulan</li>
                        <li>• Pantau siswa yang belum mengumpulkan</li>
                        <li>• Komunikasikan hasil penilaian kepada siswa</li>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal untuk Beri Nilai -->
    <div id="nilaiModal"
        class="hidden fixed inset-0 bg-gray-900 bg-opacity-75 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div class="mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Beri Nilai</h3>
                <p class="text-sm text-gray-600 mt-1">Berikan nilai dan feedback untuk siswa</p>
            </div>
            <form id="nilaiForm" method="POST" action="<?php echo e(route('guru.tugas.nilai', $tugas->id)); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="pengumpulan_id" id="pengumpulan_id">

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nilai (0-100)</label>
                    <input type="number" name="nilai" id="nilai_input"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        min="0" max="100" step="0.1" required>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Feedback</label>
                    <textarea name="feedback" id="feedback_input" rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="Berikan masukan untuk siswa..."></textarea>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeNilaiModal()"
                        class="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50">
                        Batal
                    </button>
                    <button type="submit"
                        class="flex-1 px-4 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700">
                        Simpan Nilai
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Modal functions
        function openNilaiModal(pengumpulanId, nilai = 0, feedback = '') {
            document.getElementById('pengumpulan_id').value = pengumpulanId;
            document.getElementById('nilai_input').value = nilai;
            document.getElementById('feedback_input').value = feedback;
            document.getElementById('nilaiModal').classList.remove('hidden');
        }

        function closeNilaiModal() {
            document.getElementById('nilaiModal').classList.add('hidden');
            document.getElementById('pengumpulan_id').value = '';
            document.getElementById('nilai_input').value = '';
            document.getElementById('feedback_input').value = '';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('nilaiModal');
            if (event.target == modal) {
                closeNilaiModal();
            }
        }

        // Auto-hide flash messages
        setTimeout(() => {
            const flashMessages = document.querySelectorAll('[role="alert"]');
            flashMessages.forEach(msg => {
                msg.style.transition = 'opacity 0.5s';
                msg.style.opacity = '0';
                setTimeout(() => msg.remove(), 500);
            });
        }, 3000);
    </script>
</body>

</html>
<?php /**PATH C:\Users\Asus\Desktop\elearning\resources\views/guru/tugas/pengumpulan.blade.php ENDPATH**/ ?>