<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Tugas - E-Learning</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Sidebar responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar-open {
                transform: translateX(0);
            }

            .overlay {
                display: none;
            }

            .overlay-active {
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 40;
            }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen">
    <?php echo $__env->make('guru.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="md:ml-64 min-h-screen p-4 md:p-6 transition-all duration-300">
        <!-- Header -->
        <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
            <div>
                <h1 class="text-2xl md:text-3xl font-bold text-gray-900">Manajemen Tugas</h1>
                <p class="text-gray-600 mt-1">Kelola tugas untuk siswa Anda</p>
            </div>
            <a href="<?php echo e(route('guru.tugas.create')); ?>"
                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium inline-flex items-center transition">
                <i class="fas fa-plus mr-2"></i>Buat Tugas Baru
            </a>
        </div>

        <!-- Flash Messages -->
        <?php if(session('success')): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
                <div class="flex">
                    <div class="shrink-0">
                        <i class="fas fa-check-circle text-green-500"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-green-700"><?php echo e(session('success')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Filter Tugas</h3>
            <form method="GET" action="<?php echo e(route('guru.tugas.index')); ?>">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <!-- Kelas Filter -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Kelas</label>
                        <select name="kelas"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <option value="">Semua Kelas</option>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kelasItem->id); ?>"
                                    <?php echo e(request('kelas') == $kelasItem->id ? 'selected' : ''); ?>>
                                    <?php echo e($kelasItem->kelas); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Mapel Filter -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Mata Pelajaran</label>
                        <select name="mapel"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <option value="">Semua Mapel</option>
                            <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mapel->id); ?>"
                                    <?php echo e(request('mapel') == $mapel->id ? 'selected' : ''); ?>>
                                    <?php echo e($mapel->nama_mapel); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Status Filter -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <option value="">Semua Status</option>
                            <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                            <option value="selesai" <?php echo e(request('status') == 'selesai' ? 'selected' : ''); ?>>Selesai
                            </option>
                        </select>
                    </div>

                    <!-- Search -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Cari Tugas</label>
                        <div class="flex gap-2">
                            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                placeholder="Cari judul tugas..."
                                class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <button type="submit"
                                class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg inline-flex items-center transition">
                                <i class="fas fa-filter"></i>
                            </button>
                            <a href="<?php echo e(route('guru.tugas.index')); ?>"
                                class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-3 rounded-lg inline-flex items-center transition">
                                <i class="fas fa-redo"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- Tugas List -->
        <?php if($tugas->count() > 0): ?>
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Judul Tugas
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Kelas & Mapel
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Deadline
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Komentar
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isDeadlinePassed = now()->greaterThan($item->deadline);
                                    $timeRemaining = now()->diff($item->deadline);
                                ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="font-medium text-gray-900"><?php echo e($item->judul_tugas); ?></div>
                                        <div class="text-sm text-gray-500 mt-1">
                                            <?php echo e(Str::limit($item->deskripsi, 50)); ?>

                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900"><?php echo e($item->kelas->kelas ?? '-'); ?></div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo e($item->mataPelajaran->nama_mapel ?? '-'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php echo e($item->deadline->format('d M Y, H:i')); ?>

                                        </div>
                                        <div
                                            class="text-sm <?php echo e($isDeadlinePassed ? 'text-red-500' : 'text-green-500'); ?>">
                                            <?php if($isDeadlinePassed): ?>
                                                <i class="fas fa-clock mr-1"></i> Deadline lewat
                                            <?php else: ?>
                                                <i class="fas fa-clock mr-1"></i> <?php echo e($timeRemaining->d); ?> hari
                                                <?php echo e($timeRemaining->h); ?> jam
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($isDeadlinePassed): ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                <i class="fas fa-times-circle mr-1"></i> Selesai
                                            </span>
                                        <?php else: ?>
                                            <span
                                                class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                <i class="fas fa-check-circle mr-1"></i> Aktif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center text-sm text-gray-500">
                                            <i class="fas fa-comment mr-2"></i>
                                            <?php echo e($item->komentar_count); ?> komentar
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex items-center space-x-2">
                                            <a href="<?php echo e(route('guru.tugas.show', $item)); ?>"
                                                class="text-blue-600 hover:text-blue-900 p-2 hover:bg-blue-50 rounded">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('guru.tugas.edit', $item->id)); ?>"
                                                class="text-yellow-600 hover:text-yellow-900 p-2 hover:bg-yellow-50 rounded">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('guru.tugas.destroy', $item)); ?>" method="POST"
                                                class="inline"
                                                onsubmit="return confirm('Apakah Anda yakin ingin menghapus tugas ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="text-red-600 hover:text-red-900 p-2 hover:bg-red-50 rounded">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <a href="<?php echo e(route('guru.tugas.pengumpulan', $item)); ?>"
                                                class="text-green-600 hover:text-green-900 p-2 hover:bg-green-50 rounded">
                                                <i class="fas fa-users"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pagination -->
            <?php if($tugas->hasPages()): ?>
                <div class="mt-6 bg-white rounded-xl shadow-sm p-6">
                    <?php echo e($tugas->links()); ?>

                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Empty State -->
            <div class="bg-white rounded-xl shadow-sm p-12 text-center">
                <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                    <i class="fas fa-tasks text-gray-400 text-3xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Belum ada tugas</h3>
                <p class="text-gray-600 max-w-md mx-auto mb-6">
                    Anda belum membuat tugas untuk siswa. Buat tugas pertama Anda sekarang.
                </p>
                <a href="<?php echo e(route('guru.tugas.create')); ?>"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg text-sm font-medium inline-flex items-center transition">
                    <i class="fas fa-plus mr-2"></i>Buat Tugas Pertama
                </a>
            </div>
        <?php endif; ?>

        <!-- Tips -->
        <div class="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-start">
                <i class="fas fa-lightbulb text-amber-500 mt-1 mr-3"></i>
                <div>
                    <h4 class="text-sm font-semibold text-blue-800 mb-2">Tips Manajemen Tugas:</h4>
                    <ul class="text-sm text-blue-700 space-y-1">
                        <li>• Buat tugas dengan instruksi yang jelas</li>
                        <li>• Atur deadline yang realistis</li>
                        <li>• Pantau pengumpulan siswa secara berkala</li>
                        <li>• Berikan feedback yang konstruktif</li>
                        <li>• Gunakan filter untuk mengelola banyak tugas</li>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Auto-hide flash messages
        setTimeout(() => {
            const flashMessages = document.querySelectorAll('[role="alert"]');
            flashMessages.forEach(msg => {
                msg.style.transition = 'opacity 0.5s';
                msg.style.opacity = '0';
                setTimeout(() => msg.remove(), 500);
            });
        }, 3000);
    </script>
</body>

</html>
<?php /**PATH C:\Users\Asus\Desktop\elearning\resources\views/guru/tugas/index.blade.php ENDPATH**/ ?>