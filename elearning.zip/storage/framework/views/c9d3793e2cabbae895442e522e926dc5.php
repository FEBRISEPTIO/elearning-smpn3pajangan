<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Materi Baru - E-Learning</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Sidebar responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar-open {
                transform: translateX(0);
            }

            .overlay {
                display: none;
            }

            .overlay-active {
                display: block;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 40;
            }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen">
    <?php echo $__env->make('guru.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="md:ml-64 min-h-screen p-4 md:p-6 transition-all duration-300">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6">
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold text-gray-900">Buat Materi Baru</h1>
                    <p class="text-gray-600 mt-1">Buat materi pembelajaran baru untuk siswa</p>
                </div>
                <a href="<?php echo e(route('guru.materi.index')); ?>"
                    class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-medium inline-flex items-center transition">
                    <i class="fas fa-arrow-left mr-2"></i>Kembali
                </a>
            </div>

            <?php if($errors->any()): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exclamation-circle text-red-500"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800">Ada kesalahan dalam pengisian form</h3>
                            <div class="mt-2 text-sm text-red-700">
                                <ul class="list-disc list-inside space-y-1">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form action="<?php echo e(route('guru.materi.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Judul -->
                <div class="mb-6">
                    <label for="judul" class="block text-sm font-medium text-gray-700 mb-1">
                        Judul Materi <span class="text-red-500">*</span>
                    </label>
                    <input type="text" id="judul" name="judul" required value="<?php echo e(old('judul')); ?>"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="Masukkan judul materi">
                </div>

                <!-- Kelas dan Mata Pelajaran -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <!-- Kelas -->
                    <div>
                        <label for="kelas_id" class="block text-sm font-medium text-gray-700 mb-1">
                            Kelas <span class="text-red-500">*</span>
                        </label>
                        <select id="kelas_id" name="kelas_id" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <option value="">Pilih Kelas</option>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelas_id') == $k->id ? 'selected' : ''); ?>>
                                    <?php echo e($k->kelas); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Mata Pelajaran -->
                    <div>
                        <label for="mata_pelajaran_id" class="block text-sm font-medium text-gray-700 mb-1">
                            Mata Pelajaran <span class="text-red-500">*</span>
                        </label>
                        <select id="mata_pelajaran_id" name="mata_pelajaran_id" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                            <option value="">Pilih Mata Pelajaran</option>
                            <?php $__currentLoopData = $mapels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mapel->id); ?>"
                                    <?php echo e(old('mata_pelajaran_id') == $mapel->id ? 'selected' : ''); ?>>
                                    <?php echo e($mapel->nama_mapel); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <!-- Deskripsi -->
                <div class="mb-6">
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700 mb-1">
                        Deskripsi Materi
                    </label>
                    <textarea id="deskripsi" name="deskripsi" rows="3"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="Deskripsikan materi"><?php echo e(old('deskripsi')); ?></textarea>
                </div>

                <!-- Konten Teks -->
                <div class="mb-6">
                    <label for="konten_teks" class="block text-sm font-medium text-gray-700 mb-1">
                        Konten Materi
                    </label>
                    <textarea id="konten_teks" name="konten_teks" rows="8"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="Tulis konten materi Anda di sini..."><?php echo e(old('konten_teks')); ?></textarea>
                </div>

                <!-- File Upload -->
                <div class="mb-6">
                    <label for="file" class="block text-sm font-medium text-gray-700 mb-1">
                        File Materi (Opsional)
                    </label>
                    <input type="file" id="file" name="file"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.jpg,.jpeg,.png">
                    <p class="mt-2 text-xs text-gray-500">
                        Format: PDF, DOC, DOCX, PPT, PPTX, TXT, JPG, JPEG, PNG (Maks. 20MB)
                    </p>
                </div>

                <!-- Link Video -->
                <div class="mb-6">
                    <label for="link_video" class="block text-sm font-medium text-gray-700 mb-1">
                        Link Video (Opsional)
                    </label>
                    <input type="url" id="link_video" name="link_video" value="<?php echo e(old('link_video')); ?>"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="https://youtube.com/watch?v=...">
                    <p class="mt-2 text-xs text-gray-500">
                        Contoh: YouTube, Vimeo, atau link video lainnya
                    </p>
                </div>

                <!-- Additional Settings -->
                <div class="mb-6 bg-gray-50 border border-gray-200 rounded-xl p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Pengaturan Tambahan</h3>
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" id="notify_siswa" name="notify_siswa" value="1"
                                <?php echo e(old('notify_siswa', true) ? 'checked' : ''); ?>

                                class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                            <label for="notify_siswa" class="ml-3 text-sm text-gray-700">
                                Kirim notifikasi ke siswa
                            </label>
                        </div>

                        <div class="flex items-center">
                            <input type="checkbox" id="allow_komentar" name="allow_komentar" value="1"
                                <?php echo e(old('allow_komentar', true) ? 'checked' : ''); ?>

                                class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                            <label for="allow_komentar" class="ml-3 text-sm text-gray-700">
                                Izinkan komentar pada materi
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 border-t">
                    <a href="<?php echo e(route('guru.materi.index')); ?>"
                        class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg text-sm font-medium text-center transition">
                        <i class="fas fa-times mr-2"></i>Batal
                    </a>
                    <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg text-sm font-medium inline-flex items-center justify-center transition">
                        <i class="fas fa-save mr-2"></i>Simpan Materi
                    </button>
                </div>
            </form>
        </div>

        <!-- Tips -->
        <div class="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-start">
                <i class="fas fa-lightbulb text-amber-500 mt-1 mr-3"></i>
                <div>
                    <h4 class="text-sm font-semibold text-blue-800 mb-2">Tips Membuat Materi:</h4>
                    <ul class="text-sm text-blue-700 space-y-1">
                        <li>• Judul materi harus jelas dan deskriptif</li>
                        <li>• Sertakan konten yang lengkap dan terstruktur</li>
                        <li>• Lampirkan file pendukung jika diperlukan</li>
                        <li>• Tambahkan link video untuk pembelajaran yang lebih menarik</li>
                        <li>• Pastikan materi sesuai dengan level kelas yang dituju</li>
                    </ul>
                </div>
            </div>
        </div>
    </main>
</body>

</html>
<?php /**PATH C:\Users\Asus\Desktop\elearning\resources\views/guru/materi/create.blade.php ENDPATH**/ ?>